# Forex Bot Android-Friendly V1

Upload these files to the ROOT of your GitHub repository:
- index.html
- style.css
- app.js
- manifest.json

Then enable GitHub Pages from `main` and `/(root)`.

This is designed for Chrome on Android/Samsung Galaxy A05 and is mobile responsive.

IMPORTANT: This version is a working mobile dashboard/demo interface. It does NOT place real MT5 orders. Real automated trading requires a secure backend/VPS or supported broker API/MT5 bridge. Never put broker passwords or API secrets in these browser files.

Test with CONNECT DEMO, START BOT, STOP BOT and EMERGENCY STOP.

For real trading, a secure backend must be connected to the chosen broker/MT5 account.
